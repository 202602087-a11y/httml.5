# 2026 Semiconductor Industry Newsroom — Vercel-ready

## Files
- `index.html` — the static newsroom webpage
- `vercel.json` — Vercel configuration for a static deployment

## Deploy
1. Upload both files into the same GitHub folder, for example `semiconductor-newsroom/`.
2. In Vercel, import or open the GitHub repository.
3. Set **Root Directory** to `semiconductor-newsroom` if the files are in that folder.
4. No build command or output directory is needed for this plain static HTML site.
5. Deploy from the `main` branch.

If you place these two files at the repository root instead, leave Root Directory set to `.` (the repository root).
